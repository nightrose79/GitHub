# Project Title

This is a top-level summary and motivation of Project Skeleton.

## Instructions for accessing the data

## Other top-level project information/instructions

### Example workflow

### Tips and recommendations

## Submission instructions

Here is some boilerplate to start with:
Replace the default values in `__init__.py` with your answers. Avoid running
"on-the-fly" computations or scripts in the file. The less moving parts there
are, the easier it is on the grader.

For modeling questions include information on pickling and unpickling models.

# Questions

## Question 1 (these names should match the functions in `__init__.py`)

Question statement

**Checkpoint**
Checkpoint 1: x
Checkpoint 2: y
Checkpoint 3: z

## Question 2

## Question 3
