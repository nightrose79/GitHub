# flake8: noqa
"""
This file holds sample data for validation, it is visible to fellows.
Usually this is given for modelling problems involving parsing raw data.
"""

sample_jsons_for_validation = [
    {"hip": "broken", "shoulder": "intact", "wrist": "missing"},
    {"hip": "intact", "shoulder": "fragmented", "wrist": "intact"},
    {"hip": "intact", "shoulder": "intact", "wrist": "intact"},
]
    
