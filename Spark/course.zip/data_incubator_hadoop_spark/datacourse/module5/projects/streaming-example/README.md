#### To run StreamingExample.scala:

```bash
sbt package && spark-submit target/scala-*/streaming-example*.jar
```
