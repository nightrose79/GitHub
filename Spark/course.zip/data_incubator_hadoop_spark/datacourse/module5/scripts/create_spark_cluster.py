"""
Script that creates a preconfigured Spark EMR cluster and runs a custom .jar on
the full StackExchange dataset.

Usage: python create_spark_cluster.py path/to/base/dir/ jar_name.jar
eg. python create_spark_cluster.py \
    s3://dataincubator-fellow/yourname/spark yourjar_1.jar

Base directory should contain a folder called target which contains the
packaged .jar and the classes directory
eg. s3://dataincubator-fellow/yourname/spark/target/yourjar_1.jar

For reference, the default .jar name for the SparkOverflow project is
spark-overflow_2.10-1.0.jar
"""

import argparse
import os
import subprocess
import simplejson
import boto
import time

FAIL_STATES = ['UNKNOWN', 'TERMINATED_WITH_ERRORS', 'TERMINATING']

BASH_COMMAND = "aws emr create-cluster --name 'Fellow Spark' --log-uri %s \
--instance-groups Name=Master,InstanceGroupType=MASTER,InstanceType=m3.xlarge,InstanceCount=1 \
Name=Core,InstanceGroupType=CORE,InstanceType=m3.2xlarge,InstanceCount=9 \
--auto-terminate \
--use-default-roles --ec2-attributes KeyName=dataincubator-fellows \
--ami-version 3.8.0 \
--applications Name=Spark,Args=-x \
--steps Name=SparkApp,Type=CUSTOM_JAR,Jar=s3://elasticmapreduce/libs/script-runner/script-runner.jar,\
Args=[/home/hadoop/spark/bin/spark-submit,--deploy-mode,cluster,--master,yarn-cluster,--class,ca.stevenskelton.sparkoverflow.Main,%s,s3://dataincubator-course/spark-stack-data/,%s],\
ActionOnFailure=CONTINUE"

def request_cluster(command):
  """
  Takes an aws emr create-cluster shell command, runs it, and returns the
  cluster ID.
  """
  process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
  output = process.communicate()[0]
  output_dict = simplejson.loads(output)
  cluster_id = output_dict["ClusterId"]
  print 'Spooling up cluster: ', cluster_id
  return cluster_id

if __name__ == "__main__":
  SUCCESS_FLAG = False
  PARSER = argparse.ArgumentParser(description="spool up Spark EMR cluster")
  PARSER.add_argument('base_dir', help='base directory, contains a directory \
      called target which has the packaged .jar')
  PARSER.add_argument('jar_name', help='full filename of the custom .jar file')
  ARGS = PARSER.parse_args()

  # parse jar name logic
  if ARGS.jar_name[-4:].lower() != ".jar":
    raise Exception("Invalid file type, please enter a .jar file.")
  else:
    JAR_NAME = ARGS.jar_name

  JAR_DIR = os.path.join(ARGS.base_dir, "target/") + JAR_NAME
  print "Using: " + JAR_DIR
  LOG_DIR = os.path.join(ARGS.base_dir, "logs/")
  OUT_DIR = os.path.join(ARGS.base_dir, "output/")
  print "/logs and /output folders will be created in your base directory. \
      Any pre-existing data will be overwritten!"

  BASH_STRING = BASH_COMMAND % (LOG_DIR, JAR_DIR, OUT_DIR)

  while not SUCCESS_FLAG:
    CURRENT = request_cluster(BASH_STRING)
    print 'Sleeping five minutes...'
    time.sleep(300)

    CONN = boto.connect_emr()    # uses credentials from ~/.aws
    JOBFLOW = CONN.describe_cluster(CURRENT)
    JOBSTATE = JOBFLOW.status.state
    print 'Your cluster is currently ', JOBSTATE
    if JOBSTATE in FAIL_STATES:
      print 'Trying again.'
      JOBSTATE = 'UNKNOWN'
    else:
      SUCCESS_FLAG = True
      print 'Everything looks fine for now, exiting.'
