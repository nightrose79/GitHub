"""
Simple script for checking EMR jobflow status
"""

import boto

CONN = boto.connect_emr()
if CONN.region.name != "us-east-1":
  MSG = "Error: Connected to wrong region {}".format(CONN.region.name)
  MSG += "\n    Connect to us-east-1 instead"
  raise Exception(MSG)

JOBFLOWS = CONN.describe_jobflows(states=["WAITING", "RUNNING",
                                          "STARTING"])

for job in sorted(JOBFLOWS, key=lambda u: u.state):
  queue = [step for step in job.steps
           if step.state in {"PENDING", "RUNNING"}]
  print job.jobflowid, "\t", job.state, "\t", len(queue)
