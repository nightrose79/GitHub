# Module 5: Distributed Computing with Spark

## Summary
Scala and Spark are technologies at the forefront of distributed computing that offer more abstract but more powerful APIs. This module focuses on the basics of Scala like map, flatmap, for comprehension, and data structures, and core concepts of Spark like resilient distributed datasets, memory caching, actions, transformations, tuning, and optimization. Students get to build functioning applications from end to end and learn critical tooling around Spark (sbt, jvm) to make them more productive. They apply that knowledge to directly developing, building, and deploying Spark jobs to run on large, real-world datasets in the cloud (AWS and Google Cloud Platform).

## Prerequisites
* Basic to intermediate Python or Scala
* Basic to intermediate computer science

## Notebooks
├── [Scala Primer](Scala_Primer.ipynb)
├── [Spark Intro](Spark_Intro.ipynb)
├── [PySpark Intro](PySpark_Intro.ipynb)
├── [Creating Spark Applications](Spark_Creating_Applications.ipynb)
├── [Advanced Topics in Spark](Spark_Advanced_Topics.ipynb)
├── [Spark MLlib](Spark_MLlib.ipynb)
├── [PySpark MLlib](PySpark_MLlib.ipynb)
├── [Spark Streaming](Spark_Streaming.ipynb)
└── [Scalding](Scalding.ipynb)
