# -*- coding: utf-8 -*-
"""
Created on Sun Feb 14 16:09:08 2016

@author: nightrose
"""

import numpy
import talib

close = numpy.random.random(100)